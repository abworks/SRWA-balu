function moveback(){
	window.location.assign("jsp/index.jsp");
}

function ToggleLesson(source) {
	  checkboxes = document.getElementsByName('checkLesson');
	  for(var i=0, n=checkboxes.length;i<n;i++) {
	    checkboxes[i].checked = source.checked;
	  }
	}
function ToggleLessonTest(source) {
	  checkboxes = document.getElementsByName('checkLessonTest');
	  for(var i=0, n=checkboxes.length;i<n;i++) {
	    checkboxes[i].checked = source.checked;
	  }
	}
function ToggleSubjectTest(source) {
	  checkboxes = document.getElementsByName('checkSubjectTest');
	  for(var i=0, n=checkboxes.length;i<n;i++) {
	    checkboxes[i].checked = source.checked;
	  }
	}